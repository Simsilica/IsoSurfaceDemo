#!/bin/sh
java  -jar ScatteringDemo.jar
        